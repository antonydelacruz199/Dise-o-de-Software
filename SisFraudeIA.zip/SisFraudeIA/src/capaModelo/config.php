<?php
// src/capaModelo/config.php

return [
  'db' => [
    'host'    => '127.0.0.1',
    'name'    => 'bdfraudeia',
    'user'    => 'root',
    'pass'    => '',
    'charset' => 'utf8mb4',
  ],
];
  