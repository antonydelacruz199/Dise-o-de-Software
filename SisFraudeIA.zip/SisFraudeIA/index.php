<?php
// index.php (raíz) - FINAL ROBUSTO

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

$url = $_GET['url'] ?? 'home';

function go(string $to): void {
  header("Location: $to");
  exit;
}

function first_existing(array $paths): string {
  foreach ($paths as $p) {
    if (is_file($p)) return $p;
  }
  return __DIR__ . '/src/capaVista/home.php';
}

$home = __DIR__ . '/src/capaVista/home.php';
$view = $home;

switch ($url) {

  // =========================
  // INICIO
  // =========================
  case 'home':
    $view = $home;
    break;

  // =========================
  // ANÁLISIS DE DATOS (TRÁMITES)
  // =========================
  case 'tramites.registrar':
    $view = __DIR__ . '/src/capaVista/tramites/registrar.php';
    break;

  case 'tramites.guardar':
    require __DIR__ . '/src/capaControl/tramites_control.php';
    exit;

  case 'tramites.validar':
    $tram = $_SESSION['tramite_tmp'] ?? null;

    $ok = is_array($tram)
      && isset($tram['file']['path_fs'])
      && is_string($tram['file']['path_fs'])
      && $tram['file']['path_fs'] !== ''
      && is_file($tram['file']['path_fs']);

    if (!$ok) {
      $_SESSION['flash'] = [
        'type' => 'error',
        'msg'  => 'Valide sus datos y documentos deben ser correctos. Agregue un documento antes de validar.'
      ];
      go('index.php?url=tramites.registrar');
    }

    $view = __DIR__ . '/src/capaVista/tramites/validar.php';
    break;

  case 'tramites.validar_post':
  case 'tramites.analizar_post':
    require __DIR__ . '/src/capaControl/tramites_control.php';
    exit;

  case 'tramites.analizar':
    $view = __DIR__ . '/src/capaVista/tramites/analizar.php';
    break;

  case 'tramites.informe':
    $view = __DIR__ . '/src/capaVista/tramites/informe.php';
    break;

  // ✅ alias que usas en home.php
  case 'tramites.listar':
    $view = __DIR__ . '/src/capaVista/tramites/informe.php';
    break;

  // =========================
  // ALERTAS DE FRAUDE
  // =========================
  case 'alertas':
  case 'alertas.listar':
    // ✅ si no existe listar.php, cae a generar.php
    $view = first_existing([
      __DIR__ . '/src/capaVista/alertas/listar.php',
      __DIR__ . '/src/capaVista/alertas/generar.php',
    ]);
    break;

  case 'alertas.generar':
    $view = __DIR__ . '/src/capaVista/alertas/generar.php';
    break;

  case 'alertas.caso':
    $view = __DIR__ . '/src/capaVista/alertas/caso.php';
    break;

  case 'alertas.generar_post':
  case 'alertas.asignar_post':
  case 'alertas.caso_post':
    require __DIR__ . '/src/capaControl/alertas_control.php';
    exit;

  // =========================
  // VISUALIZACIÓN
  // =========================
  case 'dashboard':
    // ✅ soporta ambos layouts
    $view = first_existing([
      __DIR__ . '/src/capaVista/dashboard/dashboard.php',
      __DIR__ . '/src/capaVista/dashboard.php',
    ]);
    break;

  // =========================
  // CONTACTO
  // =========================
  case 'contacto':
    $view = __DIR__ . '/src/capaVista/contacto.php';
    break;

  case 'contacto.enviar':
    require __DIR__ . '/src/capaControl/contacto_control.php';
    exit;

  default:
    $view = $home;
    break;
}

// fallback seguro
if (!is_file($view)) $view = $home;

?><!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SISFRAUDEIA</title>
  <link rel="stylesheet" href="assets/css/material-kit.css">
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>
<?php include $view; ?>
</body>
</html>
